package L09;

public class SearchUtil {

	public static boolean BinarySearch(int[] arr, int item)
	{
		return BinarySearchRecursive(arr, item, 0, arr.length-1);
	}
	
	public static boolean BinarySearchRecursive(int[] arr, int item, int start, int end)
	{
		//base case
		if (start > end)
			return false;
		
		//recursive
		int mid = (start + end)/2;
		
		//base case
		if(arr[mid] == item)
			return true;
		
		//recurse
		if(item<arr[mid])
			return BinarySearchRecursive(arr, item, start,mid-1);
		else
			return BinarySearchRecursive(arr, item,mid+1, end);

	}

	// A simple linear search, used to help verify correctness of binary search 
	public static boolean LinearSearch(int[] arr, int item)
	{
		for(int i : arr)
			if(i == item)
				return true;

		return false;
	}

}

