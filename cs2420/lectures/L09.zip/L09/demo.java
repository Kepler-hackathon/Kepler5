package L09;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r;
		//r = factorialLoop(4);
		//r = factorialRecursive(-1);
		r = divide(0,3);
		System.out.println(r);
	}
	
	public static int factorialLoop(int n)
	{
		int result = 1;
		for (int i=n; i>1;i--)
			result *= i;
		return result;
	}
	
	public static int factorialRecursive(int n)
	{
		
		//base case
		if (n == 0)
			return 1;
		
		//recursive work
		return factorialRecursive(n-1)*n;
	}
	
	public static int divide(int a, int b)
	{
		// base case
		if (a < b)
			return 0;
		
		// recursive work
		return 1+divide(a-b,b);
	}

}
