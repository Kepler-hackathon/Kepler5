package L09;

import java.util.Random;

public class SearchDemo {

	private static Random r;

	public static void main(String[] args) 
	{
		// Java class used to create a stream of psuedorandom numbers
		r = new Random();

		int N = 10;
		int[] arr = randomArray(N);
		sort(arr);

		// Print the sorted array
		for(int i : arr)
			System.out.print(i + " ");
		System.out.println();

		// Search for 5 random numbers
		for(int i=0; i < 5; i++)
		{
			// generate a random number to search for
			int searchFor = r.nextInt(N);
			System.out.println("Searching for " + searchFor);
			
			// use a binary search to check for the number in our array
			if(SearchUtil.BinarySearch(arr, searchFor) && SearchUtil.LinearSearch(arr, searchFor))
				System.out.println("Found\n");
			else if(SearchUtil.BinarySearch(arr, searchFor) || SearchUtil.LinearSearch(arr, searchFor))
				System.out.println("Binary search fail\n");
			else
				System.out.println("Not found\n");
		}
	}

	// make a random array of numbers
	private static int[] randomArray(int N)
	{
		int randomArray[] = new int[N];
		for(int i=0; i < N; i++)
			randomArray[i] = r.nextInt(N * 2); // Limit the max range of random values
		return randomArray;
	}

	// what sorting algorithm is this?
	private static void sort(int[] arr)
	{
		for (int i = 0; i < arr.length - 1; i++) {
			int j, minIndex;
			for (j = i + 1, minIndex = i; j < arr.length; j++)
				if(arr[j] < arr[minIndex])
					minIndex = j;
			
			int temp = arr[i];
			arr[i] = arr[minIndex];
			arr[minIndex] = temp;
		}
	}
}
