package cs2420.ta.help;

import java.awt.BasicStroke;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Grapher {
	String mxLabel, myLabel, mTitle;
	List<XYSeries> lines;
	JFreeChart mChart;
	
	public Grapher(String title, String xAxisLabel, String yAxisLabel) {
		lines = new ArrayList<XYSeries>();
		mxLabel = xAxisLabel;
		myLabel = yAxisLabel;
		mTitle = title;
	}
	
	public void addLine(List<GraphElement> elements, String lineName) {
		XYSeries series = new XYSeries(lineName);
		for (GraphElement element : elements) {
			series.add(element.x, element.y);
		}
		lines.add(series);
	}
	
	public void addLine(List<Integer>xValues, List<Double> yValues, String lineName) {
		if (xValues.size() != yValues.size()) {
			throw new IllegalArgumentException("The lists must be the same size");
		}
		XYSeries series = new XYSeries(lineName);
		for (int i = 0; i< yValues.size(); i++) { 
			series.add(xValues.get(i), yValues.get(i));
		}
		lines.add(series);
	}
	
	public void setXLabel(String xLabel) {
		mxLabel = xLabel;
	}
	
	public void setYLabel(String yLabel) {
		myLabel = yLabel;
	}
	
	public void setTitle(String title) {
		mTitle = title;
	}
	
	private void generateGraph() {
		XYSeriesCollection dataset = new XYSeriesCollection();
		for (XYSeries line : lines ){ 
			dataset.addSeries(line);
		}
		mChart = ChartFactory.createXYLineChart(mTitle, mxLabel, myLabel, dataset);
		mChart.setBackgroundPaint(Color.WHITE);
	}
	
	private void setStyle() {
		generateGraph();
		XYPlot plot = mChart.getXYPlot();
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		for(int i = 0; i < lines.size(); i++) {
			renderer.setSeriesStroke(i, new BasicStroke(3.0f));
		}
		plot.setRangeGridlinePaint(Color.BLACK);
		 
		plot.setDomainGridlinesVisible(true);
		plot.setDomainGridlinePaint(Color.BLACK);
		plot.setRenderer(renderer);
	}
	
	public void graphAsJPEG(String filename) throws IOException {
		generateGraph();
		setStyle();
		int width = 640; /* Width of the image */
	    int height = 480; /* Height of the image */ 
	    File lineChart = new File(filename); 
	    ChartUtilities.saveChartAsJPEG(lineChart,mChart, width ,height);
	}
	
	public void graphAsPNG(String filename) throws IOException {
		generateGraph();
		setStyle();
		int width = 640; /* Width of the image */
	    int height = 480; /* Height of the image */ 
	    File lineChart = new File(filename); 
	    ChartUtilities.saveChartAsPNG(lineChart,mChart, width ,height);
	}
}