package cs2420.ta.help;

public class GraphElement {
	public int x;
	public double y;
	public GraphElement(int x, double y) {
		this.x = x;
		this.y = y;
	}
	
	// default constructor should never be called
	@SuppressWarnings("unused")
	private GraphElement() {
		
	}
}
